from server_access import save_image, request_image

img = request_image()
save_image(img)
