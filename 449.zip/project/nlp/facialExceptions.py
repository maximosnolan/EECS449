class FaceAlreadyExistsException(Exception):
    pass