#!/bin/bash
python3 doorbell/camera.py
python3 facial/driver.py
